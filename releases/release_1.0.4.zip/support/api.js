"use strict";
var http = require('./http');
var log_1 = require('./log');
var API_BASE_URL = "https://api.dailymotion.com";
var API_KEY = "6a371ca96111be56feea";
var MAX_LIMIT = 100;
(function (ApiCallbackResultType) {
    ApiCallbackResultType[ApiCallbackResultType["SUCCESS"] = 0] = "SUCCESS";
    ApiCallbackResultType[ApiCallbackResultType["ERROR"] = 1] = "ERROR";
})(exports.ApiCallbackResultType || (exports.ApiCallbackResultType = {}));
var ApiCallbackResultType = exports.ApiCallbackResultType;
function call(uri, fields, filters, config, callback) {
    var url = API_BASE_URL + uri;
    var opts = {
        args: null,
        compression: true,
        caching: true
    };
    // we need to initialize args here so typescript does not assume the type of args is simply {}
    opts.args = {};
    if (fields)
        opts.args.fields = fields.join(",");
    for (var key in filters)
        opts.args[key] = filters[key];
    if (config.disableCache)
        opts.caching = false;
    // if we don't have a sort and apparently this call can use sort then use the first that config specifies as possible (the default value)
    if (!opts.args.sort && config.sorts)
        opts.args.sort = config.sorts[0][0];
    if (!opts.args.limit)
        opts.args.limit = MAX_LIMIT;
    http.request(url, opts, {
        onSuccess: function (result) {
            var json = JSON.parse(result.response);
            var obj = {
                type: ApiCallbackResultType.SUCCESS,
                json: json
            };
            callback.onSuccess(obj);
        },
        onError: function (result) {
            log_1.log.print("API call failed", log_1.LogType.ERROR);
            log_1.log.print("URL: " + url, log_1.LogType.ERROR);
            log_1.log.print("Filters", log_1.LogType.ERROR);
            log_1.log.print(filters, log_1.LogType.ERROR);
            log_1.log.print("Opts:", log_1.LogType.ERROR);
            log_1.log.print(opts, log_1.LogType.ERROR);
            log_1.log.print("Result", log_1.LogType.ERROR);
            log_1.log.print(result, log_1.LogType.ERROR);
            callback.onError({
                type: ApiCallbackResultType.ERROR,
                message: result.message
            });
        }
    }, config);
}
exports.call = call;
