"use strict";
var http = require('movian/http');
var log_1 = require('./log');
var USER_AGENT = "Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0";
(function (HttpCallbackResultType) {
    HttpCallbackResultType[HttpCallbackResultType["SUCCESS"] = 0] = "SUCCESS";
    HttpCallbackResultType[HttpCallbackResultType["ERROR"] = 1] = "ERROR";
})(exports.HttpCallbackResultType || (exports.HttpCallbackResultType = {}));
var HttpCallbackResultType = exports.HttpCallbackResultType;
function request(url, opts, callback, config) {
    config = config || {};
    opts["noFail"] = true;
    log_1.log.print("Parsing " + url);
    if (callback) {
        http.request(url, opts, function (err, response) {
            var result = createCallbackResult(err, response);
            switch (result.type) {
                case HttpCallbackResultType.SUCCESS:
                    callback.onSuccess(result);
                    break;
                case HttpCallbackResultType.ERROR:
                    if (callback.onError && !config.throwOnError)
                        callback.onError(result);
                    else
                        throwError(result);
                    break;
            }
        });
        return;
    }
    else {
        var response = http.request(url, opts);
        var result = createCallbackResult(null, response);
        if (config.throwOnError && result.type == HttpCallbackResultType.ERROR)
            throwError(result);
        else
            return createCallbackResult(null, response);
    }
}
exports.request = request;
function isSuccess(result) {
    return result.type === HttpCallbackResultType.SUCCESS;
}
exports.isSuccess = isSuccess;
function createCallbackResult(err, response) {
    if (response) {
        var statuscode = response.statuscode;
        if (statuscode == 0) {
            // response from cache
            return createCallbackSuccess(0, response);
        }
        else if (200 <= statuscode && statuscode < 400) {
            return createCallbackSuccess(statuscode, response);
        }
        else {
            return createCallbackError(statuscode, err ? err : "HTTP error");
        }
    }
    else {
        log_1.log.print(err);
        return createCallbackError(-1, err);
    }
}
function createCallbackSuccess(statuscode, response) {
    return {
        type: HttpCallbackResultType.SUCCESS,
        statuscode: statuscode,
        response: response.toString()
    };
}
function createCallbackError(statuscode, message) {
    return {
        type: HttpCallbackResultType.ERROR,
        statuscode: statuscode,
        message: message
    };
}
function throwError(error) {
    throw new Error(error.message + " [" + error.statuscode + "]");
}
