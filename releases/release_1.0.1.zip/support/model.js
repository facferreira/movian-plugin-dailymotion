"use strict";
var api = require('./api');
var general = require('./general');
var playback = require('./playback');
(function (ModelCallbackResultType) {
    ModelCallbackResultType[ModelCallbackResultType["SUCCESS"] = 0] = "SUCCESS";
    ModelCallbackResultType[ModelCallbackResultType["ERROR"] = 1] = "ERROR";
})(exports.ModelCallbackResultType || (exports.ModelCallbackResultType = {}));
var ModelCallbackResultType = exports.ModelCallbackResultType;
function getChannels(filters, config, callback) {
    api.call("/channels", getChannelFields(), filters, config, apiCallback(getChannels, callback));
}
exports.getChannels = getChannels;
function getChannelTopUsers(channelId, filters, config, callback) {
    config.disableCache = true;
    api.call("/channel/" + channelId + "/users", getUserFields(), filters, config, apiCallback(getChannelTopUsers.bind(null, channelId), callback));
}
exports.getChannelTopUsers = getChannelTopUsers;
function getChannelVideos(channelId, filters, config, callback) {
    api.call("/channel/" + channelId + "/videos", getVideoFields(), filters, config, apiCallback(getChannelVideos.bind(null, channelId), callback));
}
exports.getChannelVideos = getChannelVideos;
function getVideoPlaybackData(type, videoId) {
    var html = playback.getVideoEmbedPage(videoId);
    return {
        title: playback.getVideoTitle(html),
        sources: playback.getVideoSources(html),
        icon: playback.getVideoCover(html),
        no_fs_scan: true,
        no_subtitle_scan: true,
        canonicalUrl: general.PREFIX + ":video:" + type + ":" + videoId
    };
}
exports.getVideoPlaybackData = getVideoPlaybackData;
function searchVideos(filters, config, callback) {
    api.call("/videos", getVideoFields(), filters, config, apiCallback(searchVideos, callback));
}
exports.searchVideos = searchVideos;
function getAvailableVideoSorts(issearch) {
    var sorts = [
        ['recent', 'Most Recent', true],
        ['visited', 'Most Visited'],
        ['commented', 'Most Commented'],
        ['trending', 'Most Trending']
    ];
    if (issearch)
        sorts.push(['relevance', 'Relevance']);
    return sorts;
}
exports.getAvailableVideoSorts = getAvailableVideoSorts;
function apiCallback(model, callback) {
    return {
        onSuccess: function (result) {
            callback.onSuccess({
                type: ModelCallbackResultType.SUCCESS,
                json: result.json,
                pagination: createPaginationObject(model, result.json)
            });
        },
        onError: function (error) {
            callback.onError({
                type: ModelCallbackResultType.ERROR,
                message: error.message
            });
        }
    };
}
function createPaginationObject(model, json) {
    var pagination = {
        hasNext: json.has_more,
        next: null
    };
    if (json.has_more) {
        pagination.next = model.bind(null, json.page + 1);
    }
    return pagination;
}
function getChannelFields() {
    return [
        'id',
        'item_type',
        'name'
    ];
}
function getUserFields() {
    return [
        'avatar_360_url',
        'id',
        'item_type',
        'screenname'
    ];
}
function getVideoFields() {
    return [
        'description',
        'duration',
        'id',
        'item_type',
        'mode',
        'owner',
        'thumbnail_480_url',
        'title',
        'views_total'
    ];
}
