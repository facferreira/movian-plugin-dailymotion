"use strict";
function getRootPath() {
    return Plugin.path;
}
function getDescriptor() {
    return JSON.parse(Plugin.manifest);
}
exports.getDescriptor = getDescriptor;
function getIconPath() {
    return getRootPath() + "icon.png";
}
exports.getIconPath = getIconPath;
